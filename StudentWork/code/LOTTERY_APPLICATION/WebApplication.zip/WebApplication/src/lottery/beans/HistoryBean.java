package lottery.beans;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC, Worldwide D/B/A Trivera Technologies
 *
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Group, Inc.
 *
 * Copyright (c) 2017 Trivera Technologies, LLC. http://www.triveratech.com
 * 
 * </p>
 * 
 * @author Trivera Technologies Tech Team.
 */
import java.io.Serializable;
import java.util.Vector;

import lottery.biz.util.HistoryException;

public class HistoryBean implements Serializable {
	private static final long serialVersionUID = 1L;
	private Vector<int[]> history;
	private final int MAX = 4;

	public HistoryBean() {
		history = new Vector<int[]>(3);
	}

	public void addEntry(int[] list) {
		history.insertElementAt(list, 0);
		if (history.size() > MAX) {
			removeElement(count() - 1);
		}
	}

	public int count() {
		return history.size();
	}

	public int[] getEntry(int index) {
		if (index < count()) {
			return history.elementAt(index);
		} else {
			throw new HistoryException("No such element");
		}
	}

	public void removeElement(int index) {
		if (index < count()) {
			history.remove(index);
		} else {
			throw new HistoryException("No such element");
		}
	}

	public void clear() {
		history.clear();
	}

	public String toString() {
		return "History has " + count() + " elements";
	}
}