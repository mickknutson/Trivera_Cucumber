package lottery.biz.logic;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC, Worldwide D/B/A Trivera Technologies
 *
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Group, Inc.
 *
 * Copyright (c) 2017 Trivera Technologies, LLC. http://www.triveratech.com
 * 
 * </p>
 * 
 * @author Trivera Technologies Tech Team.
 */
import java.util.Arrays;

import lottery.biz.util.LotteryException;

public class Lottery {
	private int max = 44;
	private int count = 6;
	private int[] list;

	public Lottery() {
		generateNumbers();
	}

	public Lottery(int count, int max) {
		setMax(max);
		setCount(count);
		generateNumbers();
	}

	public int getMax() {
		return max;
	}

	public void setMax(int max) {
		if (max > 10 && max < 100) {
			this.max = max;
		} else {
			throw new LotteryException("The value supplied for the Max Range is invalid!");
		}
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		if (count > 2 && count < max) {
			this.count = count;
		} else {
			throw new LotteryException("The value supplied for the Number to pick is invalid!");
		}
	}

	public int[] getLotteryNumbers() {
		generateNumbers();
		return list;
	}

	public int[] getLotteryNumbers(int number) {
		setCount(number);
		generateNumbers();
		return list;
	}

	public int[] getLotteryNumbers(int number, int max) {
		setCount(number);
		setMax(max);
		generateNumbers();
		return list;
	}

	private void generateNumbers() {
		int current = 0;
		list = new int[getCount()];

		outerLoop: while (current < list.length) {
			int pick = (int) (Math.random() * getMax()) + 1;
			for (int i = 0; i < list.length; i++) {
				if (pick == list[i]) {
					continue outerLoop;
				}
			}
			list[current] = pick;
			current++;
		}
		Arrays.sort(list);
	}
}