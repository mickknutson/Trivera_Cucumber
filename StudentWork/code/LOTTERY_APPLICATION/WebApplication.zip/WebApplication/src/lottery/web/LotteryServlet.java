package lottery.web;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC, Worldwide D/B/A Trivera Technologies
 *
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Group, Inc.
 *
 * Copyright (c) 2017 Trivera Technologies, LLC. http://www.triveratech.com
 * 
 * </p>
 * 
 * @author Trivera Technologies Tech Team.
 */
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import lottery.beans.HistoryBean;
import lottery.biz.logic.Lottery;
import lottery.biz.util.LotteryException;

public class LotteryServlet extends HttpServlet {
	private static final long serialVersionUID = 3L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		performTask(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		performTask(request, response);
	}

	private void performTask(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		HistoryBean history = null;
		Lottery myNumbers = null;

		String firstTime = request.getParameter("startPage");
		if (firstTime != null) {

			String count = request.getParameter("size");
			String range = request.getParameter("range");
			int max = 0;
			int size = 0;
			try {
				max = Integer.parseInt(range.trim());
				size = Integer.parseInt(count.trim());

				myNumbers = new Lottery(size, max);
			} catch (LotteryException e) {
				String results = BuildErrorHTML.getPage(e.getMessage());

				response.setContentType("text/html");
				PrintWriter out = response.getWriter();
				out.println(results);
				return;
			}

			history = new HistoryBean();
			startHistory(history, myNumbers, count, range);
		} else {
			myNumbers = (Lottery) session.getAttribute("LotteryData");
			history = (HistoryBean) session.getAttribute("HistoryData");
			addToHistory(history, myNumbers);
		}
		session.setAttribute("LotteryData", myNumbers);
		session.setAttribute("HistoryData", history);

		String results = BuildHTML.getPage(history);

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println(results);
	}

	private void startHistory(HistoryBean history, Lottery myNumbers, String count, String range) {
		int[] numbers = myNumbers.getLotteryNumbers();
		history.addEntry(numbers);
	}

	private void addToHistory(HistoryBean history, Lottery myNumbers) {
		int[] numbers = myNumbers.getLotteryNumbers();
		history.addEntry(numbers);
	}
}