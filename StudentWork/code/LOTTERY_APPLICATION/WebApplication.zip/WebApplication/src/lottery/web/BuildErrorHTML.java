package lottery.web;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC, Worldwide D/B/A Trivera
 * Technologies
 *
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Group, Inc.
 *
 * Copyright (c) 2017 Trivera Technologies, LLC. http://www.triveratech.com
 * 
 * </p>
 * 
 * @author Trivera Technologies Tech Team.
 */
public class BuildErrorHTML {
	public static String getPage(String message) {
		StringBuffer results = new StringBuffer();
		results.append("<!DOCTYPE HTML");
		results.append("<html>\n" + "<head><title>Lottery Error</title>\n"
				+ "<link href='styles/Lottery.css' rel='stylesheet'" + "type='text/css' />\n</head>\n");
		results.append("<body>\n" + "<h1>There seems to be a problem...</h1>\n");
		results.append("<h3 class='center'>" + message + "</h3>");
		results.append("<input type='button' class='center' value='Try Again' onclick='window.location=\"/\"' />\n");
		results.append("</body></html>\n");
		return results.toString();
	}
}