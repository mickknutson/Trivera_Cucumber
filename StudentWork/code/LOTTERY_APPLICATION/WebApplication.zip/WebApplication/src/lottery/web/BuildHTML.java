package lottery.web;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC, Worldwide D/B/A Trivera Technologies
 *
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Group, Inc.
 *
 * Copyright (c) 2017 Trivera Technologies, LLC. http://www.triveratech.com
 * 
 * </p>
 * 
 * @author Trivera Technologies Tech Team.
 */
import lottery.beans.HistoryBean;

public class BuildHTML {
	public static String getPage(HistoryBean history) {
		StringBuffer results = new StringBuffer();
		results.append("<!DOCTYPE HTML");
		results.append("<html>\n" + "<head><title>Lottery Results</title>\n"
				+ "<link href='styles/Lottery.css' rel='stylesheet'" + "type='text/css' />\n</head>\n");
		results.append("<body>\n" + "<h1>Your Lottery Results</h1>\n");
		results.append("<table border='1'><tr>\n");
		results.append("<th>Current</th>");
		results.append("<th>Generation -1</th>");
		results.append("<th>Generation -2</th>");
		results.append("<th>Generation -3</th>");
		results.append("</tr><tr>\n");

		for (int current = 0; current < history.count(); current++) {
			int[] historyRecord = history.getEntry(current);
			results.append(buildRecord(current, historyRecord));
		}
		results.append("</tr></table>\n");
		results.append("<form method='post' action='/Lottery'>\n");
		results.append("<input type='submit' value='More Numbers?' />\n");
		results.append("<input type='button' value='Start Over' onclick='window.location=\"/\"' />\n");
		results.append("<input type='button' value='What are the Odds?' onclick='window.open(\"/Odds\")' />\n");
		results.append("</form>\n");
		results.append("</body></html>\n");
		return results.toString();
	}

	private static String buildRecord(int current, int[] input) {
		StringBuffer record = new StringBuffer();
		record.append("<td class='bigger center'>");
		for (int counter = 0; counter < input.length; counter++) {
			record.append("<span id='" + current + '-' + counter + "'>" + input[counter] + "</span><br />\n");
		}
		record.append("</td>");
		return record.toString();
	}
}