package lottery.web;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC, Worldwide D/B/A Trivera Technologies
 *
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Group, Inc.
 *
 * Copyright (c) 2017 Trivera Technologies, LLC. http://www.triveratech.com
 * 
 * </p>
 * 
 * @author Trivera Technologies Tech Team.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.text.DecimalFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import lottery.biz.logic.Lottery;

public class OddsServlet extends HttpServlet {
	private static final long serialVersionUID = 3L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		performTask(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		performTask(request, response);
	}

	private void performTask(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession(true);

		Lottery myNumbers = (Lottery) session.getAttribute("LotteryData");

		BigInteger lotteryOdds = BigInteger.valueOf(1);

		for (int i = 1; i <= myNumbers.getCount(); i++) {
			lotteryOdds = lotteryOdds.multiply(BigInteger.valueOf(myNumbers.getMax() - i + 1))
					.divide(BigInteger.valueOf(i));
		}

		DecimalFormat df2 = new DecimalFormat("###,###,###,###,###");

		String results = BuildOddsHTML.getPage(df2.format(lotteryOdds));

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println(results);
		return;

	}

}