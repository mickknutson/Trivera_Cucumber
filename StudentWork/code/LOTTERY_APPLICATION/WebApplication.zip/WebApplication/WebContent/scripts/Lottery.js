function isNumeric(input)
//  check for valid numeric strings	
{
   var validChars = "0123456789";
   var currentChar;

   if (input.length == 0) 
   {
   	return false;
   }

   //  test input consists of valid characters listed above
   for (var i = 0; i < input.length; i++)
   {
      currentChar = input.charAt(i);
      if (validChars.indexOf(currentChar) == -1)
      {
         return false;
      }
   }
   return true;
}

function checkNumbers(form)
{
	number = form.size.value;
	max = form.range.value;
	message = "";
	
	if (number == null || number == "")
	{
		message += "Please tell me the number of Lottery picks you need!\n";
	}
	
	if (max == null || max == "")
	{
		message += "Please tell me the Max Range of Lottery picks you need!\n";
	}
	
	if (isNumeric(number) == false)
	{
		message += "Number requested must be numeric\n";
	}
	
	if (isNumeric(max) == false)
	{
		message += "Max requested must be numeric\n";
	}
	
	if (message.length != 0)
	{
		alert(message);
		return false;
	}
	else
	{
		return true;
	}
}
